package com.jarvis.companion

import android.Manifest
import android.animation.ValueAnimator
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.AlarmClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.sin

private fun alpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a shl 24)

/** The glowing circle. mode: 0 = idle, 1 = listening, 2 = speaking. */
class OrbView(context: Context) : View(context) {
    var mode = 0
    var level = 0f
    private var phase = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1600
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val base = minOf(width, height) / 2f * 0.28f
        val color = when (mode) {
            1 -> 0xFF00E5FF.toInt()
            2 -> 0xFFFFB300.toInt()
            else -> 0xFF0097A7.toInt()
        }
        val wave = 0.5f + 0.5f * sin(phase * 6.2831855f)
        val pulse = when (mode) {
            1 -> 0.10f + 0.40f * level
            2 -> 0.20f
            else -> 0.06f
        }
        val r = base * (1f + pulse * wave)

        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(cx, cy, r * 2.2f, alpha(color, 110), alpha(color, 0), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 2.2f, paint)

        paint.shader = RadialGradient(cx, cy, r, alpha(Color.WHITE, 230), alpha(color, 255), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, paint)

        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 4f
        paint.color = alpha(color, 200)
        c.drawCircle(cx, cy, r * 1.3f, paint)
        paint.color = alpha(color, 90)
        c.drawCircle(cx, cy, r * 1.6f, paint)
    }
}

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private val bg = 0xFF05080F.toInt()
    private val panel = 0xFF0D1620.toInt()
    private val cyan = 0xFF00E5FF.toInt()
    private val textColor = 0xFFE6F7FF.toInt()
    private val dim = 0xFF7FA3B3.toInt()
    private val readyText = "Tap the glowing circle and speak"
    private val match = LinearLayout.LayoutParams.MATCH_PARENT
    private val wrap = LinearLayout.LayoutParams.WRAP_CONTENT

    private lateinit var chat: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var statusView: TextView
    private lateinit var orb: OrbView
    private lateinit var input: EditText
    private lateinit var confirmBar: LinearLayout
    private lateinit var confirmText: TextView

    private var pending: (() -> Unit)? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var torchOn = false

    // Only these apps can be opened (and only after you tap YES).
    private val apps = mapOf(
        "whatsapp" to "com.whatsapp",
        "chrome" to "com.android.chrome",
        "youtube" to "com.google.android.youtube",
        "maps" to "com.google.android.apps.maps",
        "gmail" to "com.google.android.gm"
    )

    private val numWords = mapOf(
        "a" to 1, "an" to 1, "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5,
        "six" to 6, "seven" to 7, "eight" to 8, "nine" to 9, "ten" to 10, "eleven" to 11,
        "twelve" to 12, "fifteen" to 15, "twenty" to 20, "thirty" to 30, "forty" to 40,
        "fifty" to 50, "sixty" to 60
    )
    private val numPattern = "\\d+|" + numWords.keys.sortedByDescending { it.length }.joinToString("|")

    private val mathRegex = Regex(
        "(-?\\d+(?:\\.\\d+)?)\\s*(\\+|plus|minus|-|times|multiplied by|x|\\*|into|divided by|over|/)\\s*(-?\\d+(?:\\.\\d+)?)"
    )

    private val jokes = listOf(
        "Why do programmers prefer dark mode? Because light attracts bugs.",
        "Why did the phone go to school? To get smarter.",
        "I would tell you a UDP joke, but you might not get it.",
        "Why was the computer cold? It left its Windows open.",
        "What is a robot's favourite snack? Microchips."
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setDecorFitsSystemWindows(false)
        setContentView(buildUi())
        tts = TextToSpeech(this, this)
        addBubble(
            "Hello! I am Jarvis, your personal companion. Tap the glowing circle and speak, " +
                "or type below. Say \"help\" to see what I can do.",
            false
        )
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        recognizer?.destroy()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- UI

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun rounded(fill: Int, stroke: Int, radiusDp: Int) = GradientDrawable().apply {
        cornerRadius = dp(radiusDp).toFloat()
        setColor(fill)
        setStroke(dp(1), stroke)
    }

    private fun pillButton(label: String, fill: Int, textCol: Int, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            setTextColor(textCol)
            background = rounded(fill, fill, 22)
            setOnClickListener { onClick() }
        }

    private fun chip(label: String, cmd: String): TextView = TextView(this).apply {
        text = label
        textSize = 14f
        setTextColor(cyan)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        background = rounded(panel, 0xFF1E5A6E.toInt(), 20)
        setOnClickListener { runCommand(cmd) }
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setOnApplyWindowInsetsListener { v, insets ->
                val b = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
                v.setPadding(b.left, b.top, b.right, b.bottom)
                insets
            }
        }

        val title = TextView(this).apply {
            text = "JARVIS"
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.3f
            setTextColor(cyan)
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, 0)
        }
        val sub = TextView(this).apply {
            text = "A personal companion"
            textSize = 12f
            setTextColor(dim)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(8))
        }
        root.addView(title, lp(match, wrap))
        root.addView(sub, lp(match, wrap))

        val chipRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), 0, dp(8), dp(6))
        }
        listOf(
            "\u23F1 Timer 1 min" to "set timer 1 minute",
            "\uD83D\uDD26 Light" to "flashlight",
            "\uD83D\uDD52 Time" to "what time is it",
            "\uD83D\uDD0B Battery" to "battery",
            "\uD83D\uDE04 Joke" to "tell me a joke",
            "\u2753 Help" to "help",
            "\uD83D\uDCDC Log" to "show log"
        ).forEach { (label, cmd) ->
            val l = lp(wrap, wrap)
            l.setMargins(dp(4), 0, dp(4), 0)
            chipRow.addView(chip(label, cmd), l)
        }
        val chipScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(chipRow)
        }
        root.addView(chipScroll, lp(match, wrap))

        chat = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4), 0, dp(4))
        }
        scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(chat)
        }
        root.addView(scroll, lp(match, 0, 1f))

        confirmText = TextView(this).apply {
            textSize = 15f
            setTextColor(textColor)
        }
        val yes = pillButton("YES", 0xFF00E676.toInt(), Color.BLACK) {
            val a = pending
            pending = null
            confirmBar.visibility = View.GONE
            a?.invoke()
        }
        val no = pillButton("NO", 0xFF2A3947.toInt(), Color.WHITE) {
            pending = null
            confirmBar.visibility = View.GONE
            say("Okay, cancelled.")
        }
        confirmBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(8), dp(10), dp(8))
            background = rounded(panel, 0xFF00B8D4.toInt(), 14)
            visibility = View.GONE
            addView(confirmText, lp(0, wrap, 1f))
            addView(no, lp(wrap, wrap))
            addView(yes, lp(wrap, wrap))
        }
        val cl = lp(match, wrap)
        cl.setMargins(dp(10), dp(4), dp(10), dp(4))
        root.addView(confirmBar, cl)

        statusView = TextView(this).apply {
            text = readyText
            textSize = 14f
            setTextColor(dim)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(4), dp(12), 0)
        }
        root.addView(statusView, lp(match, wrap))

        orb = OrbView(this)
        orb.setOnClickListener {
            if (listening) recognizer?.stopListening() else startListening()
        }
        root.addView(orb, lp(match, dp(170)))

        input = EditText(this).apply {
            hint = "Type a command\u2026"
            setHintTextColor(0xFF5E7B8A.toInt())
            setTextColor(textColor)
            textSize = 16f
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEND
            background = rounded(panel, 0xFF1E3A4C.toInt(), 22)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    sendTyped()
                    true
                } else {
                    false
                }
            }
        }
        val stop = pillButton("STOP", 0xFFB71C1C.toInt(), Color.WHITE) { stopAll() }
        val send = pillButton("SEND", cyan, Color.BLACK) { sendTyped() }
        val inputLp = lp(0, wrap, 1f)
        inputLp.setMargins(dp(6), 0, dp(6), 0)
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(8))
            addView(stop, lp(wrap, wrap))
            addView(input, inputLp)
            addView(send, lp(wrap, wrap))
        }
        root.addView(bottom, lp(match, wrap))
        return root
    }

    private fun addBubble(msg: String, mine: Boolean) {
        val tv = TextView(this).apply {
            text = msg
            textSize = 16f
            setTextColor(if (mine) Color.WHITE else textColor)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = rounded(
                if (mine) 0xFF0A4B6E.toInt() else 0xFF111C28.toInt(),
                if (mine) 0xFF00B8D4.toInt() else 0xFF1E3A4C.toInt(),
                16
            )
            maxWidth = (resources.displayMetrics.widthPixels * 0.8).toInt()
        }
        val l = lp(wrap, wrap)
        l.gravity = if (mine) Gravity.END else Gravity.START
        l.setMargins(dp(8), dp(4), dp(8), dp(4))
        chat.addView(tv, l)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun say(msg: String) {
        addBubble(msg, false)
        if (ttsReady) tts?.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    /** Ask for an on-screen YES tap. Voice can never approve this. */
    private fun ask(question: String, action: () -> Unit) {
        pending = action
        confirmText.text = question
        confirmBar.visibility = View.VISIBLE
        say("$question Please tap YES or NO on the screen.")
    }

    private fun sendTyped() {
        val s = input.text.toString()
        input.setText("")
        runCommand(s)
    }

    private fun stopAll() {
        tts?.stop()
        recognizer?.cancel()
        listening = false
        pending = null
        confirmBar.visibility = View.GONE
        orb.mode = 0
        orb.level = 0f
        statusView.text = readyText
        addBubble("Stopped.", false)
    }

    // ---------------------------------------------------------------- Speech

    override fun onInit(s: Int) {
        if (s != TextToSpeech.SUCCESS) return
        val t = tts ?: return
        val r = t.setLanguage(Locale("en", "IN"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            t.setLanguage(Locale.US)
        }
        ttsReady = true
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                runOnUiThread {
                    orb.mode = 2
                    statusView.text = "Speaking\u2026"
                }
            }

            override fun onDone(utteranceId: String?) {
                runOnUiThread {
                    if (!listening) {
                        orb.mode = 0
                        statusView.text = readyText
                    }
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                runOnUiThread { orb.mode = 0 }
            }
        })
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onRmsChanged(rmsdB: Float) {
            orb.level = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
        }

        override fun onEndOfSpeech() {
            statusView.text = "Thinking\u2026"
        }

        override fun onError(error: Int) {
            listening = false
            orb.mode = 0
            orb.level = 0f
            statusView.text = readyText
            val msg = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                    "I did not hear anything. Tap the circle and try again."
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                    "I need the microphone permission to hear you."
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                    "Speech needs internet on this phone right now. You can type instead."
                else -> "Speech error (code $error). You can type instead."
            }
            say(msg)
        }

        override fun onResults(results: Bundle?) {
            listening = false
            orb.mode = 0
            orb.level = 0f
            statusView.text = readyText
            val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!t.isNullOrBlank()) runCommand(t) else say("I did not catch that.")
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!t.isNullOrBlank()) statusView.text = "\u201C$t\u201D"
        }
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Speech recognition is not available on this phone. Please type your command.")
            return
        }
        tts?.stop()
        pending = null
        confirmBar.visibility = View.GONE
        val r = recognizer ?: SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(listener)
            recognizer = it
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        listening = true
        orb.mode = 1
        statusView.text = "Listening\u2026"
        r.startListening(i)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            say("Without the microphone I can only read typed commands.")
        }
    }

    // ---------------------------------------------------------------- Brain (rules)

    private fun runCommand(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        addBubble(text, true)
        log("CMD: $text")
        pending = null
        confirmBar.visibility = View.GONE

        val t = text.lowercase(Locale.ROOT)
            .replace("a.m.", "am").replace("p.m.", "pm")
            .replace("?", "").replace("!", "").trim()

        fun has(vararg w: String) = w.any { t.contains(it) }
        fun word(w: String) = Regex("\\b$w\\b").containsMatchIn(t)

        when {
            has("timer") -> doTimer(t)
            has("alarm") -> doAlarm(t)
            has("flashlight", "torch", "flash light") -> doTorch(t)
            Regex("^(open|launch|start) ").containsMatchIn(t) -> doOpen(t)
            Regex("^(call|dial|phone) ").containsMatchIn(t) -> doDial(t)
            Regex("^(search|google|look up)( for)? ").containsMatchIn(t) -> {
                val q = t.replace(Regex("^(search|google|look up)( for)?\\s+"), "").trim()
                if (q.isEmpty()) say("What should I search for?") else openSearch(q)
            }
            mathRegex.containsMatchIn(t) -> doMath(t)
            has("battery") -> {
                val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                say("Your battery is at $pct percent.")
            }
            word("time") -> {
                say("It is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()) + ".")
            }
            word("date") || has("what day", "which day") -> {
                say("Today is " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()) + ".")
            }
            has("joke") -> say(jokes.random())
            Regex("^(hi|hello|hey|good (morning|afternoon|evening))\\b").containsMatchIn(t) ->
                say("Hello! How can I help you?")
            has("how are you") -> say("I am running well, thank you. What can I do for you?")
            has("who are you", "your name") ->
                say("I am Jarvis, a personal companion app built on your phone. I am still learning.")
            has("thank") -> say("You are welcome.")
            has("show log", "action log") -> showLog()
            word("help") || has("what can you do") -> say(
                "I can set timers and alarms, switch the flashlight on or off, open WhatsApp, Chrome, " +
                    "YouTube, Maps or Gmail, open the dialer for a number, search the web, tell the time, " +
                    "date or battery, do simple maths, and tell jokes. For anything else I can offer to " +
                    "search the web. A real AI brain comes in a later version."
            )
            else -> ask("I do not know that yet. Search the web for it?") { openSearch(text) }
        }
    }

    private fun human(secs: Int): String {
        val h = secs / 3600
        val m = (secs % 3600) / 60
        val s = secs % 60
        val parts = mutableListOf<String>()
        if (h > 0) parts.add("$h hour" + (if (h > 1) "s" else ""))
        if (m > 0) parts.add("$m minute" + (if (m > 1) "s" else ""))
        if (s > 0) parts.add("$s second" + (if (s > 1) "s" else ""))
        return parts.joinToString(" ")
    }

    private fun doTimer(t: String) {
        var secs = 0
        if (t.contains("half an hour") || t.contains("half hour")) {
            secs = 1800
        } else {
            val m = Regex("\\b($numPattern)\\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?)\\b").find(t)
            if (m != null) {
                val n = m.groupValues[1].toIntOrNull() ?: numWords[m.groupValues[1]] ?: 0
                val u = m.groupValues[2]
                secs = when {
                    u.startsWith("h") -> n * 3600
                    u.startsWith("m") -> n * 60
                    else -> n
                }
            }
        }
        if (secs <= 0 || secs > 86400) {
            say("For how long? For example: set timer 5 minutes.")
            return
        }
        try {
            startActivity(
                Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, secs)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "Jarvis timer")
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            )
            say("Timer set for ${human(secs)}.")
            log("ACTION: timer $secs seconds")
        } catch (e: Exception) {
            say("I could not set the timer on this phone.")
        }
    }

    private fun doAlarm(t: String) {
        val m = Regex("(\\d{1,2})(?:[:\\s](\\d{2}))?\\s*(am|pm)?").find(t)
        if (m == null) {
            say("What time? For example: set alarm 7 30 am.")
            return
        }
        val h = m.groupValues[1].toInt()
        val min = m.groupValues[2].ifEmpty { "0" }.toInt()
        val ap = m.groupValues[3]
        if (h > 23 || min > 59) {
            say("That time does not look right.")
            return
        }
        if (ap.isEmpty() && h in 1..12) {
            say("AM or PM? For example: set alarm $h am.")
            return
        }
        var h24 = h
        if (ap == "pm" && h < 12) h24 = h + 12
        if (ap == "am" && h == 12) h24 = 0
        val h12 = if (h24 % 12 == 0) 12 else h24 % 12
        val label = String.format(Locale.US, "%d:%02d %s", h12, min, if (h24 >= 12) "PM" else "AM")
        try {
            startActivity(
                Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, h24)
                    .putExtra(AlarmClock.EXTRA_MINUTES, min)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "Jarvis alarm")
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            )
            say("Alarm set for $label.")
            log("ACTION: alarm $label")
        } catch (e: Exception) {
            say("I could not set the alarm on this phone.")
        }
    }

    private fun doTorch(t: String) {
        val on = when {
            Regex("\\boff\\b").containsMatchIn(t) -> false
            Regex("\\bon\\b").containsMatchIn(t) -> true
            else -> !torchOn
        }
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) {
                say("This phone has no flashlight I can use.")
                return
            }
            cm.setTorchMode(id, on)
            torchOn = on
            say(if (on) "Flashlight on." else "Flashlight off.")
            log("ACTION: flashlight $on")
        } catch (e: Exception) {
            say("I could not control the flashlight.")
        }
    }

    private fun doOpen(t: String) {
        val name = t.replace(Regex("^(open|launch|start)\\s+"), "").trim()
        val key = apps.keys.firstOrNull { name.contains(it) }
        if (key == null) {
            say("I can only open: " + apps.keys.joinToString(", ") + ". This keeps you safe.")
            return
        }
        ask("Open $key?") {
            val i = packageManager.getLaunchIntentForPackage(apps[key] ?: "")
            if (i == null) {
                say("$key is not installed on this phone.")
            } else {
                startActivity(i)
                log("ACTION: open $key")
            }
        }
    }

    private fun doDial(t: String) {
        val num = Regex("[+\\d][\\d\\s\\-]{4,}").find(t)?.value?.filter { it.isDigit() || it == '+' }
        if (num.isNullOrEmpty()) {
            say("Which number? For example: call 9876543210. I do not call contact names, for your safety.")
            return
        }
        ask("Open the dialer for $num?") {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", num, null)))
            log("ACTION: dial $num")
        }
    }

    private fun openSearch(q: String) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))
            )
            say("Searching the web for $q.")
            log("ACTION: search")
        } catch (e: ActivityNotFoundException) {
            say("I could not find a browser to open.")
        }
    }

    private fun fmt(d: Double): String =
        if (d == Math.floor(d) && Math.abs(d) < 1e12) {
            d.toLong().toString()
        } else {
            String.format(Locale.US, "%.4f", d).trimEnd('0').trimEnd('.')
        }

    private fun doMath(t: String) {
        val m = mathRegex.find(t)
        if (m == null) {
            say("I could not read that sum.")
            return
        }
        val a = m.groupValues[1].toDouble()
        val b = m.groupValues[3].toDouble()
        val res: Double? = when (m.groupValues[2]) {
            "+", "plus" -> a + b
            "-", "minus" -> a - b
            "x", "*", "times", "multiplied by", "into" -> a * b
            else -> if (b == 0.0) null else a / b
        }
        if (res == null) say("I cannot divide by zero.") else say("The answer is ${fmt(res)}.")
    }

    private fun log(line: String) {
        try {
            val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            File(filesDir, "actions.log").appendText("$stamp $line\n")
        } catch (e: Exception) {
            // logging must never crash the app
        }
    }

    private fun showLog() {
        val f = File(filesDir, "actions.log")
        if (!f.exists()) {
            addBubble("The action log is empty.", false)
            return
        }
        addBubble("Last actions:\n" + f.readLines().takeLast(8).joinToString("\n"), false)
    }
}
