package com.jarvis.companion

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), RecognitionListener {

    private lateinit var heard: TextView
    private lateinit var reply: TextView
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var dialog: AlertDialog? = null

    // Only these apps can be opened. Add more here.
    private val apps = mapOf(
        "whatsapp" to "com.whatsapp",
        "chrome" to "com.android.chrome",
        "youtube" to "com.google.android.youtube",
        "maps" to "com.google.android.apps.maps",
        "gmail" to "com.google.android.gm"
    )

    private val numberWords = mapOf(
        "zero" to "0", "one" to "1", "two" to "2", "three" to "3", "four" to "4",
        "five" to "5", "six" to "6", "seven" to "7", "eight" to "8", "nine" to "9",
        "ten" to "10", "eleven" to "11", "twelve" to "12", "fifteen" to "15",
        "twenty" to "20", "thirty" to "30", "forty" to "40", "fifty" to "50", "sixty" to "60"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad * 3, pad, pad)

        val title = TextView(this)
        title.text = "Jarvis"
        title.textSize = 30f
        val subtitle = TextView(this)
        subtitle.text = "A personal companion"
        subtitle.textSize = 16f
        heard = TextView(this)
        heard.text = "Heard: -"
        heard.textSize = 18f
        heard.setPadding(0, pad, 0, pad)
        reply = TextView(this)
        reply.text = "Reply: -"
        reply.textSize = 18f
        reply.setPadding(0, 0, 0, pad)

        val talk = Button(this)
        talk.text = "TALK"
        talk.textSize = 22f
        talk.setOnClickListener { startListening() }
        val stop = Button(this)
        stop.text = "STOP"
        stop.setOnClickListener { stopAll() }
        val logBtn = Button(this)
        logBtn.text = "ACTION LOG"
        logBtn.setOnClickListener { showLog() }

        root.addView(title)
        root.addView(subtitle)
        root.addView(heard)
        root.addView(reply)
        root.addView(talk)
        root.addView(stop)
        root.addView(logBtn)
        setContentView(root)

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setLanguage(Locale.getDefault())
                ttsReady = true
            }
        }
    }

    override fun onDestroy() {
        tts?.shutdown()
        recognizer?.destroy()
        super.onDestroy()
    }

    // ---------- voice in ----------
    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Speech recognition is not available on this phone.")
            return
        }
        tts?.stop()
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(this)
        recognizer = r
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
        heard.text = "Listening..."
        r.startListening(intent)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            say("Microphone allowed. Tap TALK again.")
        } else {
            say("I need the microphone to hear you.")
        }
    }

    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}
    override fun onError(error: Int) {
        heard.text = "Heard: -"
        say("I could not hear that. Error $error.")
    }
    override fun onResults(results: Bundle?) {
        val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val text = list?.firstOrNull() ?: ""
        heard.text = "Heard: $text"
        handle(text)
    }

    // ---------- rules router (no AI) ----------
    private fun normalize(raw: String): String {
        var t = raw.lowercase(Locale.ROOT).trim()
        t = t.replace("a.m.", "am").replace("p.m.", "pm")
        for ((word, digit) in numberWords) {
            t = t.replace(Regex("\\b$word\\b"), digit)
        }
        return t
    }

    private fun handle(raw: String) {
        val t = normalize(raw)
        when {
            t.isBlank() -> say("I did not hear anything.")
            t == "stop" || t == "cancel" -> stopAll()
            t.contains("timer") -> doTimer(raw, t)
            t.contains("alarm") -> doAlarm(raw, t)
            t.contains("flashlight") || t.contains("torch") -> doTorch(raw, t)
            t.startsWith("open ") -> doOpen(raw, t.removePrefix("open ").trim())
            t.startsWith("call ") || t.startsWith("dial ") -> doDial(raw, t.substringAfter(" ").trim())
            t.startsWith("search ") || t.startsWith("google ") ->
                doSearch(raw, t.substringAfter(" ").removePrefix("for ").trim())
            else -> {
                log(raw, "none", "not understood")
                say("I did not understand.")
            }
        }
    }

    // ---------- actions ----------
    private fun doTimer(raw: String, t: String) {
        val m = Regex("(\\d+)\\s*(second|minute|hour)").find(t)
        if (m == null) {
            log(raw, "timer", "no duration")
            say("Say for example: set timer 5 minutes.")
            return
        }
        val n = m.groupValues[1].toInt()
        val unit = m.groupValues[2]
        val secs = when (unit) {
            "second" -> n
            "minute" -> n * 60
            else -> n * 3600
        }
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
        i.putExtra(AlarmClock.EXTRA_LENGTH, secs)
        i.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        launch(raw, "timer $secs s", "Timer set for $n $unit.", i)
    }

    private fun doAlarm(raw: String, t: String) {
        val m = Regex("(\\d{1,2})(?:[: ](\\d{2}))?\\s*(am|pm)?").find(t.substringAfter("alarm"))
        if (m == null) {
            log(raw, "alarm", "no time")
            say("Say for example: set alarm for 7:30 am.")
            return
        }
        var hour = m.groupValues[1].toInt()
        val minute = if (m.groupValues[2].isEmpty()) 0 else m.groupValues[2].toInt()
        val ampm = m.groupValues[3]
        if (ampm == "pm" && hour < 12) hour += 12
        if (ampm == "am" && hour == 12) hour = 0
        if (hour > 23 || minute > 59) {
            log(raw, "alarm", "bad time")
            say("That time does not look right.")
            return
        }
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
        i.putExtra(AlarmClock.EXTRA_HOUR, hour)
        i.putExtra(AlarmClock.EXTRA_MINUTES, minute)
        i.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        val shownMinute = minute.toString().padStart(2, '0')
        launch(raw, "alarm $hour:$shownMinute", "Alarm set for $hour:$shownMinute.", i)
    }

    private fun doTorch(raw: String, t: String) {
        val on = !t.contains("off")
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: throw IllegalStateException("no flash")
            cm.setTorchMode(id, on)
            log(raw, "flashlight", if (on) "on" else "off")
            say(if (on) "Flashlight on." else "Flashlight off.")
        } catch (e: Exception) {
            log(raw, "flashlight", "failed: ${e.javaClass.simpleName}")
            say("I could not use the flashlight.")
        }
    }

    private fun doSearch(raw: String, query: String) {
        if (query.isBlank()) {
            say("Say for example: search for weather today.")
            return
        }
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query)))
        launch(raw, "search", "Searching for $query.", i)
    }

    // L2 actions: need an on-screen tap
    private fun doOpen(raw: String, name: String) {
        val pkg = apps[name]
        if (pkg == null) {
            log(raw, "open $name", "blocked: not in allowlist")
            say("$name is not in my allowed apps.")
            return
        }
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) {
            log(raw, "open $name", "not installed")
            say("$name is not installed.")
            return
        }
        confirm("Open $name?") { launch(raw, "open $name", "Opening $name.", intent) }
    }

    private fun doDial(raw: String, arg: String) {
        val digits = arg.filter { it.isDigit() || it == '+' }
        if (digits.length < 3) {
            log(raw, "dial", "no number")
            say("I can only dial numbers. Say: call 9 8 7 6 5 4 3 2 1 0.")
            return
        }
        confirm("Open the dialer for $digits? You will still tap Call.") {
            launch(raw, "dial $digits", "Dialer opened.", Intent(Intent.ACTION_DIAL, Uri.parse("tel:$digits")))
        }
    }

    // ---------- gate, stop, log ----------
    private fun confirm(question: String, onYes: () -> Unit) {
        dialog?.dismiss()
        say(question)
        dialog = AlertDialog.Builder(this)
            .setTitle("Please confirm")
            .setMessage(question)
            .setPositiveButton("YES") { _, _ -> onYes() }
            .setNegativeButton("NO") { _, _ ->
                log("-", question, "denied by owner")
                say("Cancelled.")
            }
            .show()
    }

    private fun launch(raw: String, action: String, okText: String, intent: Intent) {
        try {
            startActivity(intent)
            log(raw, action, "ok")
            say(okText)
        } catch (e: Exception) {
            log(raw, action, "failed: ${e.javaClass.simpleName}")
            say("That did not work on this phone.")
        }
    }

    private fun say(text: String) {
        reply.text = "Reply: $text"
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "r1")
    }

    private fun stopAll() {
        tts?.stop()
        recognizer?.cancel()
        dialog?.dismiss()
        heard.text = "Heard: -"
        reply.text = "Reply: stopped"
        log("-", "stop", "stopped speech, listening and confirm box")
    }

    private fun log(cmd: String, action: String, result: String) {
        val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        File(filesDir, "audit.log").appendText("$ts | $cmd | $action | $result\n")
    }

    private fun showLog() {
        val f = File(filesDir, "audit.log")
        val body = if (f.exists()) f.readLines().takeLast(30).joinToString("\n") else "No actions yet."
        val tv = TextView(this)
        tv.text = body
        tv.textSize = 12f
        tv.setPadding(32, 32, 32, 32)
        val sv = ScrollView(this)
        sv.addView(tv)
        AlertDialog.Builder(this)
            .setTitle("Action log")
            .setView(sv)
            .setPositiveButton("CLOSE", null)
            .show()
    }
}
